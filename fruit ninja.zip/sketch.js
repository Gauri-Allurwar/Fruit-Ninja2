var PLAY =1;
var END = 0;
var gameState = PLAY;

var sword;
var score;

var swordImage,fruit1Image,fruit2Image,fruit3Image,fruit4Image;
var alien1Image,alien2Image;
var fruitsGroup,alienGroup;
var gameOverImage,gameOver;

function preload(){
  
  swordImage = loadImage("sword.png");
  fruit1Image = loadImage("fruit1.png");
  fruit2Image = loadImage("fruit2.png");
  fruit3Image = loadImage("fruit3.png");
  fruit4Image = loadImage("fruit4.png");
  alien1Image = loadImage("alien1.png");
  alien2Image = loadImage("alien2.png");
  gameOverImage= loadImage("gameover.png");
}



function setup() {
  createCanvas(600,600);
  
  sword = createSprite(40,200,20,20);
  sword.addImage(swordImage);
  sword.scale = 0.7;
  
  score = 0; 
  
  gameOver = createSprite(300,300,40,50);
  gameOver.addImage(gameOverImage);
 
  fruitsGroup = createGroup();
  alienGroup = createGroup();
}

function draw() {
  background  ("lightblue");
  text("Score : "+score,280,50);
  
  sword.x = mouseX;
  sword.y = mouseY;
  
  if(gameState === PLAY){
    
    if(sword.isTouching(fruitsGroup)){
      fruitsGroup.destroyEach();
      score = score + 2;
    }
    
    if(sword.isTouching(alienGroup)){
      gameState = END;
    }
    
    createFruits();
    createAlien();
    gameOver.visible = false;
  }
  
  if(gameState === END){
    fruitsGroup.destroyEach();
    alienGroup.destroyEach();
    sword.visible = false;
    gameOver.visible = true;
  }
  
  
  drawSprites();

}

function createFruits(){
  if(frameCount % 60 === 0){
    var fruit = createSprite(600,80,20,20);
    fruit.y = Math.round(random(20,570));
    fruit.velocityX = -4;
    fruit.scale = 0.15;
    var b = Math.round(random(1,4));
    switch(b){
      case 1:
        fruit.addImage(fruit1Image);
        break;
      case 2:
        fruit.addImage(fruit2Image);
        break;
      case 3:
        fruit.addImage(fruit3Image);
        break;
      case 4:
        fruit.addImage(fruit4Image);
        break;
    }
    fruitsGroup.add(fruit);
  }
}

function createAlien(){
  if(frameCount%120 === 0){
    var alien = createSprite(600,80,20,10);
    alien.y = Math.round(random(20,570));
    alien.velocityX = -4;
    var a = Math.round(random(1,2));
    switch(a){
      case 1:
        alien.addImage(alien1Image);
        break;
      case 2:
        alien.addImage(alien2Image);
        break;
    }
    
    alienGroup.add(alien);
  }
}
